#include <stdio.h>

int main(void) {
  double x, y;


scanf("%lf %lf", &x, &y);

if ((x == 0.0) && (y == 0.0)) 
  printf("origem\n");

else if ((x > 0) && (y > 0))
  printf("Q1\n");
 
else if ((x < 0) && (y > 0))
  printf("Q2\n");
 
else if ((x < 0) && (y < 0))
  printf("Q3\n");
 
else if ((x > 0) && (y < 0))
  printf("Q4\n");
 
else if (x == 0)
  printf("eixo Y\n");
 
else if (y == 0) 
  printf("eixo X\n"); 

  return 0;
}