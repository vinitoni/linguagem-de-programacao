#include <stdio.h>

int main(void) {

int i, j, inicio, fim, soma;
int n,troca; 
 soma=0;

scanf("%d", &n);
for (i = 0; i < n; i++){
  scanf("%d", &inicio);
  scanf("%d", &fim);

  if (inicio > fim){
    troca = inicio;
    inicio = fim;
    fim = troca;
  }
  for (j = inicio+1; j < fim; j++){
    if (!(j % 2 == 0)){
        soma = soma + j;
    }
  }
printf("%d\n", soma);
}

  return 0;
}