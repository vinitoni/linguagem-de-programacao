#include <stdio.h>
int main(){
    int n,i;
    double nota1,nota2,nota3;

    scanf("%i",&n);
    for (i=0;i<n;i++){
        scanf("%lf %lf %lf", &nota1, &nota2, &nota3);
        printf("%.1lf\n",(nota1*2 + nota2*3 + nota3*5)/10);
    }
    return 0;
}