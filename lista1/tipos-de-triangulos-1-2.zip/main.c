#include <stdio.h>
#include <math.h>

int main(void) {

float A, B, C;

scanf("%f %f %f", &A, &B, &C);

if (C > B) {
  int troca = B;
  B = C;
  C = troca;
}

if (C > A) {
  int troca = A;
    A = C;
    C = troca;

}

if (B > A) {
  int troca = A;
  A = B;
  B = troca;
}

if (A >= B + C) {
  printf("NAO FORMA TRIANGULO\n");
}

else if ( A*A == B*B + C*C) {
  printf("TRIANGULO RETANGULO\n");
}

else if (A*A > B*B + C*C){
  printf("TRIANGULO OBTUSANGULO\n");
}

else if (A*A < B*B + C*C){
  printf("TRIANGULO ACUTANGULO\n");
}

if (A==B && B==C){
   printf("TRIANGULO EQUILATERO\n");
}else if (A==B || B==C){
   printf("TRIANGULO ISOSCELES\n");
 }
 
  return 0;
}