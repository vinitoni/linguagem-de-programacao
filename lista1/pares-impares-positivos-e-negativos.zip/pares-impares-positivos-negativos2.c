#include <stdio.h>

int main() {

  int par, impar, pos, neg;
  int cont;
  int x;
  par = 0;
  impar = 0;
  pos = 0;
  neg = 0;

  cont = 1;
  while (cont<=6){
    scanf("%d", &x);

    if (x%2 == 0) par++;
    if (x%2 != 0) impar++;
    if (x > 0) pos++;
    if (x < 0) neg++;
    cont ++;
  }
  

 
 printf("%d valor(es) par(es)\n", par);
 printf("%d valor(es) impar(es)\n", impar);
 printf("%d valor(es) positivo(s)\n", pos);
 printf("%d valor(es) negativo(s)\n", neg);

    return 0;
}